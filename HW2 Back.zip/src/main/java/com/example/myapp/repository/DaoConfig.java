package com.example.myapp.repository; 
import org.springframework.context.annotation.Configuration ; 
import org.springframework.context.annotation.ComponentScan ; 
@ComponentScan(value="com.example.dao")
@Configuration
public class DaoConfig {
    
}