package com.example.myapp.dto;

import lombok.Data;

@Data
public class BookRank {
    int book_id ; 
    String bookname ; 
    int sold ; 
}
