package com.example.myapp.dto;

public class User_dto {
    
}
