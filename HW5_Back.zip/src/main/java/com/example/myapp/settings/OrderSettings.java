package com.example.myapp.settings;

public class OrderSettings {
    public static final String CalculatorFuncUri = "/price" ; 
    public static final String FunctionName = "getPrice" ; 
};