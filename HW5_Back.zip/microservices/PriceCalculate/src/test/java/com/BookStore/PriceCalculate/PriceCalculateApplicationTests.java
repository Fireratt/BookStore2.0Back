package com.BookStore.PriceCalculate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceCalculateApplicationTests {

	@Test
	void contextLoads() {
	}

}
