cd F:\\Work\\Kafka\\kafka_2.13-3.8.0\\kafka_2.13-3.8.0
./bin/windows/kafka-server-stop.bat
./bin/windows/zookeeper-server-stop.bat
echo 输入任意键关闭...
read
