cd F:\\Work\\Kafka\\kafka_2.13-3.8.0\\kafka_2.13-3.8.0
echo 输入继续
read
./bin/zookeeper-server-start.sh config/zookeeper.properties &
./bin/kafka-server-start.sh config/server.properties
echo 输入任意键关闭...
read
