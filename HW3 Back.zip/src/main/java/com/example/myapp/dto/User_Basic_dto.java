package com.example.myapp.dto;

public class User_Basic_dto {
    
}
